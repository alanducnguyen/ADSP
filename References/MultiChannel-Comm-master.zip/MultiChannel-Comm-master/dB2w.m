function y=dB2w(dB)
y=10.^(0.1*dB);