These MATLAB programs in this directory belong to the book titled "MIMO-OFDM Wireless Communication with MATLAB��",
which has been authored by Yong Soo Cho, Jaekwon Kim, Won Young Yang, and Chung G. Kang and published by John Wiley & Sons (Asia) Pte Ltd in 2010.
All Rights Reserved. No part of this publication may be reproduced, stored in a retrieval system, or transmitted in any form or by any means, 
without the prior written permission of the publisher. 

Limits of Liability and Disclaimer of Warranty of Software
The authors and publisher of this book have used their best efforts and knowledge in preparing this book as well as developing the computer programs in it. 
However, they make no warranty of any kind, expressed or implied, with regard to the programs or the documentation contained in this book. 
Accordingly, they shall not be liable for any incidental or consequential damages in connection with, or arising out of, the readers��use of, 
or reliance upon, the material in this book.
