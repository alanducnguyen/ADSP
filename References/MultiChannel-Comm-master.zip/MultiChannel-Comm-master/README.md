# mimo
MIMO techniques with MATLAB.
The examples from the book MIMO-OFDM Wireless Communications with MATLAB.
Codes also available at http://www.wiley.com//legacy/wileychi/cho/matlab.html
